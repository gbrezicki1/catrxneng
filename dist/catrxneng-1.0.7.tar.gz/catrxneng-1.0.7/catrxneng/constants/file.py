R = {"J/mol/K": 8.314, "kJ/mol/K": 0.008314}
mol_gas_vol = {"nL/mol": 24.05, "sL/mol": 22.4}